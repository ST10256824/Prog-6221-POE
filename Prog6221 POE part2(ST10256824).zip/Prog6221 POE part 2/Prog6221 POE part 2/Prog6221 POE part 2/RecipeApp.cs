﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog6221_POE_part_2
{
    internal class RecipeApp
    {
        class Ingredient
        {

            public string Name { get; set; }
            public double Quantity { get; set; }
            public string Unit { get; set; }
            public double Calories { get; set; }
            public string FoodGroup { get; set; }
        }

        class step
        {

            public string Description { get; set; }
        }

        class recipe
        {

            public string Name { get; set; }
            public List<Ingredient> Ingredients { get; set; }
            public List<Step> Steps { get; set; }

            public double TotalCalories => Ingredients.Sum(i => i.Calories * i.Quantity);
        }
        class RecipeManager()
        {
            private List<Recipe> recipes = new List<Recipe>();
            public delegate void RecipeExceedsCaloriesEventHandler(Recipe recipe);

            public event RecipeExceedsCaloriesEventHandler RecipeExceedsCalories;

            public void CreateRecipe()
            {

                Recipe recipe = new Recipe();

                Console.WriteLine("Enter recipe name:");
                recipe.Name = Console.ReadLine();

                Console.WriteLine("Enter the number of ingredients:");
                int numIngredients = int.Parse(Console.ReadLine());
                recipe.Ingredients = new List<Ingredient>();

                for (int i = 0; i < numIngredients; i++)
                {
                    Console.WriteLine($"Enter details for ingredient {i + 1}:");
                    Console.Write("Name: ");
                    string name = Console.ReadLine();
                    Console.Write("Quantity: ");
                    double quantity = double.Parse(Console.ReadLine());
                    Console.Write("Unit: ");
                    string unit = Console.ReadLine();
                    Console.Write("Calories: ");
                    double calories = double.Parse(Console.ReadLine());
                    Console.Write("Food Group: ");
                    string foodGroup = Console.ReadLine();

                    recipe.Ingredients.Add(new Ingredient { Name = name, Quantity = quantity, Unit = unit, Calories = calories, FoodGroup = foodGroup });

                }
                Console.WriteLine("Enter the number of steps:");
                int numSteps = int.Parse(Console.ReadLine());
                recipe.Steps = new List<Step>();

                for (int i = 0; i < numSteps; i++)
                {
                    Console.WriteLine($"Enter step {i + 1}:");
                    string description = Console.ReadLine();

                    recipe.Steps.Add(new Step { Description = description });

                }
                recipes.Add(recipe);
                if (recipe.TotalCalories > 300)
                {
                    RecipeExceedsCalories?.Invoke(recipe);
                }

            }

            public void DisplayRecipe(string recipeName)
            {
                Recipe recipe = recipes.FirstOrDefault(r => r.Name == recipeName);
                if (recipe == null)
                {
                    Console.WriteLine("Recipe not found.");
                    return;
                }
                Console.WriteLine($"\nRecipe: {recipe.Name}");
                Console.WriteLine("Ingredients:");
                foreach (var ingredient in recipe.Ingredients)
                {
                    Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name} ({ingredient.Calories} calories) - {ingredient.FoodGroup}");
                }

                Console.WriteLine("\nSteps:");
                for (int i = 0; i < recipe.Steps.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. {recipe.Steps[i].Description}");
                }
                public void ClearRecipe(){
                    recipes.Clear();
                    Console.WriteLine("All recipes cleared.");
                }
            }
            public void DisplayAllRecipes()
            {
                Console.WriteLine("\nAll Recipe:");
                foreach (var recipe in recipes.OrderBy(recipe => recipe.Name){
                    Console.WriteLine(recipe.Name)
                }


            }

            private class Recipe
            {
                internal string? Name;
                internal List<Ingredient> Ingredients;

                public List<Step> Steps { get; internal set; }
                public int TotalCalories { get; internal set; }
            }

            private class Step
            {
                public string Description { get; set; }
            }
        }
}
