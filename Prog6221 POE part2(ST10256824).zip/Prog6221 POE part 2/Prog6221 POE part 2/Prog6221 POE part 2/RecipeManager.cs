﻿
namespace Prog6221_POE_part_2
{
    internal class RecipeManager
    {
        internal readonly object recipes;

        public int RecipeExceedsCalories { get; internal set; }

        internal void ClearRecipes()
        {
            throw new NotImplementedException();
        }

        internal void CreateRecipe()
        {
            throw new NotImplementedException();
        }

        internal void DisplayAllRecipes()
        {
            throw new NotImplementedException();
        }

        internal void DisplayRecipe(string? recipeName)
        {
            throw new NotImplementedException();
        }
    }
}