﻿namespace Prog6221_POE_part_2
{
    internal class UnitTest
    {
        public class RecipeManagerTests
        {
            // Arrange
            var recipe = new recipe
            {
                Name = "Test Recipe",
                Ingredients = new List<Ingredient>
                {
                    new Ingredient { Name = "Ingredient1", Quantity = 1, Unit = "unit", Calories = 100, FoodGroup = "Group1" },
                    new Ingredient { Name = "Ingredient2", Quantity = 2, Unit = "unit", Calories = 150, FoodGroup = "Group2" }
                },
                Steps = new List<Step>
                {
                    new Step { Description = "Step 1" },
                    new Step { Description = "Step 2" }
                };
            // Act 
            double totalCalories = recipe.TotalCalories;

            // Assert
            Assert.AreEqual(400, totalCalories, "Total calories calculation is incorrect.);


            }
        }

    }
}
