﻿using GenFu.ValueGenerators.Cooking;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog6221_POE_part_2
{
    internal class Main
    {
        public static int RecipeExceedsCaloriesHandler { get; private set; }

        static void Main(string[] args)
        {

            RecipeManager recipeManager = new RecipeManager();

            recipeManager.RecipeExceedsCalories += RecipeExceedsCaloriesHandler;

            // Adding recipes
            AddRecipes(recipeManager);

            bool exit = false;
            while (!exit)
            {
                Console.WriteLine("\nMenu:");
                Console.WriteLine("1. Create Recipe");
                Console.WriteLine("2. Display All Recipes");
                Console.WriteLine("3. Display Recipe");
                Console.WriteLine("4. Clear Recipes");
                Console.WriteLine("5. Exit");
                Console.Write("Enter your choice: ");
                int choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        recipeManager.CreateRecipe();
                        break;
                    case 2:
                        recipeManager.DisplayAllRecipes();
                        break;
                    case 3:
                        Console.Write("Enter recipe name: ");
                        string recipeName = Console.ReadLine();
                        recipeManager.DisplayRecipe(recipeName);
                        break;
                    case 4:
                        recipeManager.ClearRecipes();
                        break;
                    case 5:
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;

                }
                static void AddRecipe(RecipeManager recipeManager)
                {
                    recipeManager.recipes.Add(new recipe
                    {

                        new = "Chocolate Cake",
                        Ingredients new List<Ingredient>{
            new Ingredient { Name = "Flour", Quantity = 2, Unit = "cups", Calories = 220, FoodGroup = "Grains" },
            new Ingredient { Name = "Sugar", Quantity = 1.5, Unit = "cups", Calories = 774, FoodGroup = "Sweets" },
            new Ingredient { Name = "Cocoa Powder", Quantity = 0.75, Unit = "cup", Calories = 98, FoodGroup = "Sweets" },
            new Ingredient { Name = "Baking Powder", Quantity = 2, Unit = "tsp", Calories = 5, FoodGroup = "Condiments" }
    },
                        step = new List<Step>{
            new Step { Description = "Preheat oven to 350°F (175°C)." },
            new Step { Description = "Grease and flour a 9x13-inch baking pan." },
            new Step { Description = "In a large mixing bowl, combine flour, sugar, cocoa powder, and baking powder." },
            new Step { Description = "Add eggs, milk, oil, and vanilla extract. Beat on medium speed for 2 minutes." },
            new Step { Description = "Pour batter into prepared pan." },
            new Step { Description = "Bake in preheated oven for 30 to 35 minutes, or until a toothpick inserted into the center comes out clean." },
            new Step { Description = "Allow to cool before serving." }
    }

                    }) ;
                    // Recipe 2 
                    recipeManager.recipes.Add(new Recipe
                    {
                        Name = "Chicken Curry",
                        Ingredients = new List<Ingredient>{
            new Ingredient { name = "Spice", Quantity = 1, uint = "grams", Calories = 20, FoodGroup = "Grains"},
            new Ingredient { name = "Water", Quantity 1/2, Unit = "cup", Calories = 100, FoodGroup = "Liquid" },
        },
                        Steps = new List<Step>{
            new Step { "Boil in a pot till chicken is soft."}
            New Step { "Add spice "}

        }
                    });
                    recipes.Add(new Recipe
                    {
                        Name = "Chicken curry",
                        Ingredients = new List<Ingredient>{
                    new Ingredient { Name = "Chicken Breast", Quantity = 1, Unit = "lb", Calories = 231, FoodGroup = "Protein" },
                    new Ingredient { Name = "Onion", Quantity = 1, Unit = "cup", Calories = 64, FoodGroup = "Vegetables" },
                    new Ingredient { Name = "Garlic", Quantity = 3, Unit = "cloves", Calories = 13, FoodGroup = "Vegetables" },
                    new Ingredient { Name = "Tomato", Quantity = 2, Unit = "cups", Calories = 48, FoodGroup = "Vegetables" },
                    new Ingredient { Name = "Coconut Milk", Quantity = 1, Unit = "cup", Calories = 552, FoodGroup = "Dairy" },
                    new Ingredient { Name = "Curry Powder", Quantity = 2, Unit = "tbsp", Calories = 16, FoodGroup = "Spices" }

        },
                        Steps = new List<Step>{
                    new Step { Description = "Cut the chicken into cubes." },
                    new Step { Description = "Chop the onions and garlic." },
                    new Step { Description = "Cook the onions and garlic until soft." },
                    new Step { Description = "Add the chicken and cook until browned." },
                    new Step { Description = "Add tomatoes, coconut milk, and curry powder." },
            }
                    });

                    recipe.Add(new Recipe
                    {
                        Name = "Tomato Pasta",
                        Ingredients = new List<Ingredient>{
                         new Ingredient { Name = "Pasta", Quantity = 2, Unit = "cups", Calories = 400, FoodGroup = "Grains" },
                    new Ingredient { Name = "Tomato Sauce", Quantity = 1, Unit = "cup", Calories = 74, FoodGroup = "Vegetables" },
                    new Ingredient { Name = "Olive Oil", Quantity = 2, Unit = "tbsp", Calories = 238, FoodGroup = "Oils" },
                    new Ingredient { Name = "Garlic", Quantity = 2, Unit = "cloves", Calories = 8, FoodGroup = "Vegetables" },
                    new Ingredient { Name = "Basil", Quantity = 1, Unit = "tbsp", Calories = 1, FoodGroup = "Spices" }

           },
                        Steps = new List<Step>{
                        new Step { Description = "Cook the pasta according to package instructions." },
                    new Step { Description = "Heat the olive oil and cook the garlic until fragrant." },
                    new Step { Description = "Add the tomato sauce and basil and simmer for 10 minutes." },
                    new Step { Description = "Combine the pasta and sauce." }
                }
                    });

                    // Vegetable Stir-Fry
                    recipes.Add(new Recipe
                    {
                        Name = "Vegetable Stir-Fry",
                        Ingredients = new List<Ingredient>
                {
                    new Ingredient { Name = "Bell Pepper", Quantity = 1, Unit = "cup", Calories = 24, FoodGroup = "Vegetables" },
                    new Ingredient { Name = "Broccoli", Quantity = 2, Unit = "cups", Calories = 55, FoodGroup = "Vegetables" },
                    new Ingredient { Name = "Carrot", Quantity = 1, Unit = "cup", Calories = 50, FoodGroup = "Vegetables" },
                    new Ingredient { Name = "Soy Sauce", Quantity = 3, Unit = "tbsp", Calories = 30, FoodGroup = "Condiments" },
                    new Ingredient { Name = "Olive Oil", Quantity = 1, Unit = "tbsp", Calories = 119, FoodGroup = "Oils" },
                    new Ingredient { Name = "Garlic", Quantity = 2, Unit = "cloves", Calories = 8, FoodGroup = "Vegetables" }
                },
                        Steps = new List<Step>
                {
                    new Step { Description = "Chop the vegetables." },
                    new Step { Description = "Heat the olive oil in a pan." },
                    new Step { Description = "Add the garlic and cook until fragrant." },
                    new Step { Description = "Add the vegetables and cook until tender." },
                    new Step { Description = "Add soy sauce and stir to combine." }
                }
                    });

                    // Beef Stew
                    recipes.Add(new Recipe
                    {
                        Name = "Beef Stew",
                        Ingredients = new List<Ingredient>
                {
                    new Ingredient { Name = "Beef", Quantity = 1, Unit = "lb", Calories = 679, FoodGroup = "Protein" },
                    new Ingredient { Name = "Potatoes", Quantity = 3, Unit = "cups", Calories = 342, FoodGroup = "Vegetables" },
                    new Ingredient { Name = "Carrots", Quantity = 1, Unit = "cup", Calories = 50, FoodGroup = "Vegetables" },
                    new Ingredient { Name = "Onion", Quantity = 1, Unit = "cup", Calories = 64, FoodGroup = "Vegetables" },
                    new Ingredient { Name = "Beef Broth", Quantity = 2, Unit = "cups", Calories = 20, FoodGroup = "Soups" },
                    new Ingredient { Name = "Tomato Paste", Quantity = 2, Unit = "tbsp", Calories = 30, FoodGroup = "Vegetables"
}

        });

                    recipes.Add(new Recipe
                    {
                        Name = "Vegetable Stir-Fry",
                        Ingredients = new List<Ingredient>{

                     new Ingredient { Name = "Bell Pepper", Quantity = 1, Unit = "cup", Calories = 24, FoodGroup = "Vegetables" },
                    new Ingredient { Name = "Broccoli", Quantity = 2, Unit = "cups", Calories = 55, FoodGroup = "Vegetables" },
                    new Ingredient { Name = "Carrot", Quantity = 1, Unit = "cup", Calories = 50, FoodGroup = "Vegetables" },
                    new Ingredient { Name = "Soy Sauce", Quantity = 3, Unit = "tbsp", Calories = 30, FoodGroup = "Condiments" },
                    new Ingredient { Name = "Olive Oil", Quantity = 1, Unit = "tbsp", Calories = 119, FoodGroup = "Oils" },
                    new Ingredient { Name = "Garlic", Quantity = 2, Unit = "cloves", Calories = 8, FoodGroup = "Vegetables" }
    },
                        Steps = new List<Step>{
                new Step { Description = "Chop the vegetables." },
                    new Step { Description = "Heat the olive oil in a pan." },
                    new Step { Description = "Add the garlic and cook until fragrant." },
                    new Step { Description = "Add the vegetables and cook until tender." },
                    new Step { Description = "Add soy sauce and stir to combine." }

     }
                    });

                }


            }









        }

        private static void AddRecipes(RecipeManager recipeManager)
        {
            throw new NotImplementedException();
        }
    }

    internal class recipe
    {
        public List<Step> step { get; set; }
        public List<Ingredient> Ingredients { get; internal set; }
        public List<Step> Steps { get; internal set; }
        public string Name { get; internal set; }
    }
}
