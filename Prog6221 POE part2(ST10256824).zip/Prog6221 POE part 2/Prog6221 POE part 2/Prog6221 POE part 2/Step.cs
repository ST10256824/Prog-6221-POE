﻿namespace Prog6221_POE_part_2
{
    internal class Step
    {
        public string Description { get; set; }
    }
}