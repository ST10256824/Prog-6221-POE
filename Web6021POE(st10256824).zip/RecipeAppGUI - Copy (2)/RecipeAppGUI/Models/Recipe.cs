﻿using System.Collections.Generic;
using System.Linq;

namespace RecipeAppGUI.Models
{
    public class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; }
        public List<Step> Steps { get; set; }

        public double TotalCalories => Ingredients.Sum(i => i.Calories * i.Quantity);
    }
}
