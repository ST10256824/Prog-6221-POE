﻿namespace RecipeAppGUI.Models
{
    public enum FoodGroup
    {
        Protein,
        Vegetables,
        Grains,
        Dairy,
        Oils,
        Spices,
        Condiments,
        Soups
    }

    public class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
        public double Calories { get; set; }
        public FoodGroup FoodGroup { get; set; }
    }
}

