﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using RecipeAppGUI.Models;
using LiveCharts;
using LiveCharts.Wpf;

namespace RecipeAppGUI
{
    public partial class MainWindow : Window
    {
        private List<Recipe> recipes = new List<Recipe>();

        public MainWindow()
        {
            InitializeComponent();
            LoadPredefinedRecipes();
            FilterFoodGroupComboBox.ItemsSource = Enum.GetValues(typeof(FoodGroup));
        }

        private void LoadPredefinedRecipes()
        {
            // Add predefined recipes 
            recipes.Add(new Recipe
            {
                Name = "Chicken Curry",
                Ingredients = new List<Ingredient>
                {
                    new Ingredient { Name = "Chicken Breast", Quantity = 1, Unit = "lb", Calories = 231, FoodGroup = FoodGroup.Protein },
                    new Ingredient { Name = "Onion", Quantity = 1, Unit = "cup", Calories = 64, FoodGroup = FoodGroup.Vegetables },
                    new Ingredient { Name = "Garlic", Quantity = 3, Unit = "cloves", Calories = 13, FoodGroup = FoodGroup.Vegetables },
                    new Ingredient { Name = "Tomato", Quantity = 2, Unit = "cups", Calories = 48, FoodGroup = FoodGroup.Vegetables },
                    new Ingredient { Name = "Coconut Milk", Quantity = 1, Unit = "cup", Calories = 552, FoodGroup = FoodGroup.Dairy },
                    new Ingredient { Name = "Curry Powder", Quantity = 2, Unit = "tbsp", Calories = 16, FoodGroup = FoodGroup.Spices }
                },
                Steps = new List<Step>
                {
                    new Step { Description = "Cut the chicken into cubes." },
                    new Step { Description = "Chop the onions and garlic." },
                    new Step { Description = "Cook the onions and garlic until soft." },
                    new Step { Description = "Add the chicken and cook until browned." },
                    new Step { Description = "Add tomatoes, coconut milk, and curry powder." },
                    new Step { Description = "Simmer for 20 minutes." }
                }
            });

            recipes.Add(new Recipe
            {
                Name = "Tomato Pasta",
                Ingredients = new List<Ingredient>
                {
                    new Ingredient { Name = "Pasta", Quantity = 2, Unit = "cups", Calories = 400, FoodGroup = FoodGroup.Grains },
                    new Ingredient { Name = "Tomato Sauce", Quantity = 1, Unit = "cup", Calories = 74, FoodGroup = FoodGroup.Vegetables },
                    new Ingredient { Name = "Olive Oil", Quantity = 2, Unit = "tbsp", Calories = 238, FoodGroup = FoodGroup.Oils },
                    new Ingredient { Name = "Garlic", Quantity = 2, Unit = "cloves", Calories = 8, FoodGroup = FoodGroup.Vegetables },
                    new Ingredient { Name = "Basil", Quantity = 1, Unit = "tbsp", Calories = 1, FoodGroup = FoodGroup.Spices }
                },
                Steps = new List<Step>
                {
                    new Step { Description = "Cook the pasta according to package instructions." },
                    new Step { Description = "Heat the olive oil and cook the garlic until fragrant." },
                    new Step { Description = "Add the tomato sauce and basil and simmer for 10 minutes." },
                    new Step { Description = "Combine the pasta and sauce." }
                }
            });
            recipes.Add(new Recipe
            {
                Name = "Beef stew"
                Ingredients new List<Ingredeint>
                {
                    new Ingredient { Name = "Beef", Quantity = 1, Unit = "lb", Calories = 679, FoodGroup = "Protein" },
                    new Ingredient { Name = "Potatoes", Quantity = 3, Unit = "cups", Calories = 342, FoodGroup = "Vegetables" },
                    new Ingredient { Name = "Carrots", Quantity = 1, Unit = "cup", Calories = 50, FoodGroup = "Vegetables" },
                    new Ingredient { Name = "Onion", Quantity = 1, Unit = "cup", Calories = 64, FoodGroup = "Vegetables" },
                    new Ingredient { Name = "Beef Broth", Quantity = 2, Unit = "cups", Calories = 20, FoodGroup = "Soups" },
                    new Ingredient { Name = "Tomato Paste", Quantity = 2, Unit = "tbsp", Calories = 30, FoodGroup = "Vegetables"
                    }

                });

            recipes.Add(new Recipe
            {
                Name = "Vegetable Stir-Fry",
                Ingredients = new List<Ingredient>{

                     new Ingredient { Name = "Bell Pepper", Quantity = 1, Unit = "cup", Calories = 24, FoodGroup = "Vegetables" },
                    new Ingredient { Name = "Broccoli", Quantity = 2, Unit = "cups", Calories = 55, FoodGroup = "Vegetables" },
                    new Ingredient { Name = "Carrot", Quantity = 1, Unit = "cup", Calories = 50, FoodGroup = "Vegetables" },
                    new Ingredient { Name = "Soy Sauce", Quantity = 3, Unit = "tbsp", Calories = 30, FoodGroup = "Condiments" },
                    new Ingredient { Name = "Olive Oil", Quantity = 1, Unit = "tbsp", Calories = 119, FoodGroup = "Oils" },
                    new Ingredient { Name = "Garlic", Quantity = 2, Unit = "cloves", Calories = 8, FoodGroup = "Vegetables" }
    },
                Steps = new List<Step>{
                new Step { Description = "Chop the vegetables." },
                    new Step { Description = "Heat the olive oil in a pan." },
                    new Step { Description = "Add the garlic and cook until fragrant." },
                    new Step { Description = "Add the vegetables and cook until tender." },
                    new Step { Description = "Add soy sauce and stir to combine." }

     }
            });
        }

        private void AddRecipe_Click(object sender, RoutedEventArgs e)
        {
            var addRecipeWindow = new AddRecipeWinwow();
            if (addRecipeWindow.ShowDialog()== true)
            {
                recipes.Add(addRecipeWindow.NewRecipe);
                DisplayAllRecipes_Click(null, null);

            }
                    
                    }

        private void DisplayAllRecipes_Click(object sender, RoutedEventArgs e)
        {
            RecipeListView.ItemsSource = recipes.OrderBy(r => r.Name).ToList();
        }

        private void FilterRecipes_Click(object sender, RoutedEventArgs e)
        {
        }

        private void CreateMenu_Click(object sender, RoutedEventArgs e)
        {
            var selectedRecipes = RecipeListView.SelectedItems.Cast<Recipe>().ToList();
            var foodGroupCounts = selectedRecipes
                .SelectMany(r => r.Ingredients)
                .GroupBy(i => i.FoodGroup)
                .Select(g => new { FoodGroup = g.Key, Count = g.Count() })
                .ToDictionary(g => g.FoodGroup, g => g.Count);

            var pieChart = new PieChart
            {
                Width = 400,
                Height = 400,
                Series = new SeriesCollection()
            };

            foreach (var foodGroupCount in foodGroupCounts)
            {
                pieChart.Series.Add(new PieSeries
                {
                    Title = foodGroupCount.Key.ToString(),
                    Values = new ChartValues<int> { foodGroupCount.Value },
                    DataLabels = true
                });
            }

            var chartWindow = new Window
            {
                Title = "Food Group Distribution",
                Content = pieChart,
                Width = 450,
                Height = 450
            };

            chartWindow.ShowDialog();
       
        }

        private void ApplyFilter_Click(object sender, RoutedEventArgs e)
        {
            string ingredient = FilterIngredientTextBox.Text.ToLower();
            FoodGroup? foodGroup = FilterFoodGroupComboBox.SelectedItem as FoodGroup?;
            int maxCalories = string.IsNullOrEmpty(MaxCaloriesTextBox.Text) ? int.MaxValue : int.Parse(MaxCaloriesTextBox.Text);

            var filteredRecipes = recipes.Where(r =>
                (string.IsNullOrEmpty(ingredient) || r.Ingredients.Any(i => i.Name.ToLower().Contains(ingredient))) &&
                (!foodGroup.HasValue || r.Ingredients.Any(i => i.FoodGroup == foodGroup)) &&
                r.TotalCalories <= maxCalories).ToList();

            RecipeListView.ItemsSource = filteredRecipes;
        }
    }
}
